"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameen Abbasi
ID:      210427860
Email:   abba7860@mylaurier.ca
__updated__ = "2022-01-20"
-------------------------------------------------------
"""
from Stack_array import Stack
from Queue_array import Queue
from Priority_Queue_array import Priority_Queue
from List_array import List
def array_to_stack(stack, source):
    """
    -------------------------------------------------------
    Pushes contents of source onto stack. At finish, source is empty.
    Last value in source is at bottom of stack,
    first value in source is on top of stack.
    Use: array_to_stack(stack, source)
    -------------------------------------------------------
    Parameters:
        stack - a Stack object (Stack)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while source != []:
        stack.push(source[-1])
        source.pop()
    return

def stack_to_array(stack, target):
    """
    -------------------------------------------------------
    Pops contents of stack into target. At finish, stack is empty.
    Top value of stack is at end of target,
    bottom value of stack is at beginning of target.
    Use: stack_to_array(stack, target)
    -------------------------------------------------------
    Parameters:
        stack - a Stack object (Stack)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while not stack.is_empty():
        value = stack.pop()
        target.insert(0,value)
    return
        
    
def stack_test(source):
    """
    -------------------------------------------------------
    Tests the methods of Stack for empty and
    non-empty stacks using the data in source:
    is_empty, push, pop, peek
    (Testing pop and peek while empty throws exceptions)
    Use: stack_test(source)
    -------------------------------------------------------
    Parameters:
        source - list of data (list of ?)
    Returns:
        None
    -------------------------------------------------------
    """
    stack = Stack()
    for object in stack:
        print(object)
    if stack.is_empty():
        for item in source:
            stack.push(item)
    for object in stack:
        print(object)
    v = stack.peek()
    x = stack.pop()
    print(v)
    print(x)
    for object in stack:
        print(object)
def array_to_queue(queue, source):
    """
    -------------------------------------------------------
    Inserts contents of source into queue. At finish, source is empty.
    Last value in source is at rear of queue,
    first value in source is at front of queue.
    Use: array_to_queue(queue, source)
    -------------------------------------------------------
    Parameters:
        queue - a Queue object (Queue)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while len(source)!=0:
        queue.insert(source.pop(0))
    return 

def queue_to_array(queue, target):
    """
    -------------------------------------------------------
    Removes contents of queue into target. At finish, queue is empty.
    Front value of queue is at front of target,
    rear value of queue is at end of target.
    Use: queue_to_array(queue, target)
    -------------------------------------------------------
    Parameters:
        queue - a Queue object (Queue)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while not(queue.is_empty()):
        value = queue.remove()
        target.append(value)
    return

def queue_test(a):
    """
    -------------------------------------------------------
    Tests queue implementation.
    Tests the methods of Queue are tested for both empty and
    non-empty queues using the data in a:
    is_empty, insert, remove, peek, len
    Use: queue_test(a)
    -------------------------------------------------------
    Parameters:
        a - list of data (list of ?)
    Returns:
        None
    -------------------------------------------------------
    """
    q = Queue()
    bool = q.is_empty()
    print(f'This should be empty: {bool}')
    for item in a:
        q.insert(item)
    for item in q:
        print(item)
    print(f'this should not be empty: {q.is_empty()}')
    print(f"The first value in list is {q.peek()} and {a[0]}")
    print(f"the lengths should be equal, {len(q)} and {len(a)}")
    q.remove()
    for item in q:
        print(item)
    return
def array_to_pq(pq, source):
    """
    -------------------------------------------------------
    Inserts contents of source into pq. At finish, source is empty.
    Last value in source is at rear of pq,
    first value in source is at front of pq.
    Use: array_to_pq(pq, source)
    -------------------------------------------------------
    Parameters:
        pq - a Priority_Queue object (Priority_Queue)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while len(source)!=0:
        pq.insert(source.pop(0))
    return

def pq_to_array(pq, target):
    """
    -------------------------------------------------------
    Removes contents of pq into target. At finish, pq is empty.
    Highest priority value in pq is at front of target,
    lowest priority value in pq is at end of target.
    Use: pq_to_array(pq, target)
    -------------------------------------------------------
    Parameters:
        pq - a Priority_Queue object (Priority_Queue)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while not(pq.is_empty()):
        value = pq.remove()
        target.append(value)
    return

def priority_queue_test(a):
    """
    -------------------------------------------------------
    Tests priority queue implementation.
    Test the methods of Priority_Queue are tested for both empty and
    non-empty priority queues using the data in a:
        is_empty, insert, remove, peek
    Use: priority_queue_test(a)
    -------------------------------------------------------
    Parameters:
        a - list of data (list of ?)
    Returns:
        None
    -------------------------------------------------------
    """
    pq = Priority_Queue()
    bool = pq.is_empty()
    print(f'This should be empty: {bool}')
    for item in a:
        pq.insert(item)
    for item in pq:
        print(item)
    print(f'this should not be empty: {pq.is_empty()}')
    print(f"The first value in list is {pq.peek()} and {a[0]}")
    print(f"the lengths should be equal, {len(pq)} and {len(a)}")
    pq.remove()
    for item in pq:
        print(item)
    return

def array_to_list(llist, source):
    """
    -------------------------------------------------------
    Appends contents of source to llist. At finish, source is empty.
    Last element in source is at rear of llist,
    first element in source is at front of llist.
    Use: array_to_list(llist, source)
    -------------------------------------------------------
    Parameters:
        llist - a List object (List)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while len(source)!=0:
        value = source.pop(0)
        llist.append(value)
    return

def list_to_array(llist, target):
    """
    -------------------------------------------------------
    Removes contents of llist into target. At finish, llist is empty.
    Front element of llist is at front of target,
    rear element of llist is at rear of target.
    Use: list_to_array(llist, target) 
    -------------------------------------------------------
    Parameters:
        llist - a List object (List)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while len(llist)!=0:
        value = llist.pop(0)
        target.append(value)
    return
def list_test(source):
    """
    -------------------------------------------------------
    Tests List implementation.
    The methods of List are tested for both empty and
    non-empty lists using the data in source
    Use: list_test(source)
    -------------------------------------------------------
    Parameters:
        source - list of data (list of ?)
    Returns:
        None
    -------------------------------------------------------
    """
    lst = List()
    print(f'this is supposed to be true: {lst.is_empty()}')
    print(f'this is supposed to be None: {lst.remove(2)}')
    for item in source:
        lst.append(item)
    print(f'this is supposed to be false: {lst.is_empty()}')
    print(f'this is supposed to be 2: {lst.count(10)}')
    print(f'this is supposed to be None: {lst.remove(2)}')
    for item in lst:
        print(item)
    print(f'this is supposed to equal 4: {lst.index(0)}')
    print(f'this is supposed to be 14 : {lst.max()}')
    print(f'this is supposed to be 0: {lst.min()}')
    print(f'this is supposed to be 10: {lst.peek()}')
    print(f'this is supposed to be 10: {lst.find(10)}')
    print(f'{lst.insert(0,5)}')
    for item in lst:
        print(item)
    return