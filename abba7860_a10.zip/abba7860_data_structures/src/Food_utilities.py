"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameen Abbasi
ID:      210427860
Email:   abba7860@mylaurier.ca
__updated__ = "2022-01-07"
-------------------------------------------------------
"""
from Food import Food
from copy import deepcopy
def get_food():
    """
    -------------------------------------------------------
    Creates a food object by requesting data from a user.
    Use: f = get_food()
    -------------------------------------------------------
    Returns:
        food - a completed food object (Food).
    -------------------------------------------------------
    """
    name = input("Name: ")
    for num in range(len(Food.ORIGIN)):
        food = Food.ORIGIN[num]
        print(f"{num: >2} {food}")
    origin = int(input("Origin: "))
    vg = (input("Vegetarian (Y/N): "))
    if vg=="Y":
        is_vegetarian = True
    elif vg=="N":
        is_vegetarian = False
    calories = int(input("Calories: "))
    food = Food(name, origin, is_vegetarian, calories)
    return food
    
def read_food(line):
    """
    -------------------------------------------------------
    Creates and returns a food object from a line of string data.
    Use: f = read_food(line)
    -------------------------------------------------------
    Parameters:
        line - a vertical bar-delimited line of food data in the format
          name|origin|is_vegetarian|calories (str)
    Returns:
        food - contains the data from line (Food)
    -------------------------------------------------------
    """
    foodlist = line.split("|")
    name = foodlist[0]
    origin = int(foodlist[1])
    if foodlist[2]=="True":
        is_vegetarian= True
    elif foodlist[2]=="False":
        is_vegetarian=False
    calories = int(foodlist[3])
    food = Food(name,origin,is_vegetarian,calories)
    return food

def read_foods(file_variable):
    """
    -------------------------------------------------------
    Reads a file of food strings into a list of Food objects.
    Use: foods = read_foods(file_variable)
    -------------------------------------------------------
    Parameters:
        file_variable - an open file of food data (file)
    Returns:
        foods - a list of food objects (list of Food)
    -------------------------------------------------------
    """
    foods = []
    for line in file_variable:
        foodlist = line.split("|")
        name = foodlist[0]
        origin = int(foodlist[1])
        if foodlist[2]=="True":
            is_vegetarian= True
        elif foodlist[2]=="False":
            is_vegetarian=False
        calories = int(foodlist[3])
        food = Food(name,origin,is_vegetarian,calories)
        foods.append(food)
    return foods
      
def write_foods(file_variable, foods):
    """
    -------------------------------------------------------
    Writes a list of food objects to a file.
    file_variable contains the objects in foods as strings in the format
    name|origin|is_vegetarian|calories
    foods is unchanged.
    Use: write_foods(file_variable, foods)
    -------------------------------------------------------
    Parameters:
        file_variable - an open file of food data (file)
        foods - a list of Food objects (list of Food)
    Returns:
        None
    -------------------------------------------------------
    """
    for item in foods:
        line = f'{item.name}|{item.origin}|{item.is_vegetarian}|{item.calories}\n'
        file_variable.write(line)
    return file_variable
        

def get_vegetarian(foods):
    """
    -------------------------------------------------------
    Creates a list of vegetarian foods.
    foods is unchanged.
    Use: v = get_vegetarian(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        veggies - Food objects from foods that are vegetarian (list of Food)
    -------------------------------------------------------
    """
    veggies =  []
    for item in foods:
        if item.is_vegetarian==True:
            veggies.append(item)
    return veggies

def by_origin(foods, origin):
    """
    -------------------------------------------------------
    Creates a list of foods by origin.
    foods is unchanged.
    Use: v = by_origin(foods, origin)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - a food origin (int)
    Returns:
        origins - Food objects from foods that are of a particular origin (list of Food)
    -------------------------------------------------------
    """
    assert origin in range(len(Food.ORIGIN))
    origins = []
    for food in foods:
        if food.origin==origin:
            origins.append(food)
    return origins

def average_calories(foods):
    """
    -------------------------------------------------------
    Determines the average calories in a list of foods.
    foods is unchanged.
    Use: avg = average_calories(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        avg - average calories in all Food objects of foods (int)
    -------------------------------------------------------
    """
    total = 0
    denom = 0
    for food in foods:
        total += food.calories
        denom +=1
    avg = total//denom
    return avg
def calories_by_origin(foods, origin):
    """
    -------------------------------------------------------
    Determines the average calories in a list of foods.
    foods is unchanged.
    Use: a = calories_by_origin(foods, origin)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - the origin of the Food objects to find (int)
    Returns:
        avg - average calories for all Foods of the requested origin (int)
    -------------------------------------------------------
    """
    assert origin in range(len(Food.ORIGIN))
    foods = by_origin(foods, origin)
    avg = average_calories(foods)
    return avg
    

def food_table(foods):
    """
    -------------------------------------------------------
    Prints a formatted table of foods, sorted by name.
    foods is unchanged.
    Use: food_table(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        None
    -------------------------------------------------------
    """
    foodlist = deepcopy(foods)
    foodlist.sort()
    print(f"Food                                Origin       Vegetarian Calories")
    print("----------------------------------- ------------ ---------- --------")
    for food in foodlist:
        print(f'{food.name: <35} {Food.ORIGIN[food.origin]: <12} {food.is_vegetarian: >10} {food.calories: >8}')
    return

def food_search(foods, origin, max_cals, is_veg):
    """
    -------------------------------------------------------
    Searches for foods that fit certain conditions.
    foods is unchanged.
    Use: results = food_search(foods, origin, max_cals, is_veg)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - the origin of the food; if -1, accept any origin (int)
        max_cals - the maximum calories for the food; if 0, accept any calories value (int)
        is_veg - whether the food is vegetarian or not; if False accept any food (boolean)
    Returns:
        result - a list of foods that fit the conditions (list of Food)
            foods parameter must be unchanged
    -------------------------------------------------------
    """
    assert origin in range(-1, len(Food.ORIGIN))
    result = []
    for food in foods:
        if food.origin==origin or origin==-1:
            if food.calories<=max_cals or max_cals==0:
                if is_veg==False or is_veg==food.is_vegetarian:
                    result.append(food)
    return result