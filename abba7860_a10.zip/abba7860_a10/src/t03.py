"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameen Abbasi
ID:      210427860
Email:   abba7860@mylaurier.ca
__updated__ = "2022-04-02"
-------------------------------------------------------
"""
from Sorts_array import Sorts
a = [2,34,35,12,12345,13,6,3,14,515,23446,23]
Sorts.gnome_sort(a)
print(a)