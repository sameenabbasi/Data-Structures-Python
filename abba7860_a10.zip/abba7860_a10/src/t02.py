"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameen Abbasi
ID:      210427860
Email:   abba7860@mylaurier.ca
__updated__ = "2022-04-02"
-------------------------------------------------------
"""
from List_linked import List
from Sorts_List_linked import Sorts
arr = [55, 45, 32657,43, 35, 4643,413 , 421, 341,351, 12,3, 1, 2]
a = List()
for value in arr:
    a.append(value)
Sorts.radix_sort(a)
lst = []
for value in a:
    lst.append(value)
print(lst)
    