"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameen Abbasi
ID:      210427860
Email:   abba7860@mylaurier.ca
__updated__ = "2022-04-02"
-------------------------------------------------------
"""
from Deque_linked import Deque
from Sorts_Deque_linked import Sorts
arr = [23,45,1,23,445,3,23,213,3432523,123,11]
a = Deque()
for value in arr:
    a.insert_rear(value)
Sorts.gnome_sort(a)
lst = []
for value in a:
    lst.append(value)
print(lst)